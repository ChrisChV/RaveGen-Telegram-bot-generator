import os

def getInput(_string):
    val = raw_input(_string)
    return val    

