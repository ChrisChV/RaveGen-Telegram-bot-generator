#!/usr/bin/env python
import sys
import ConsoleEngine.consoleAPI as consoleAPI
import Utils.utils as utils

#TOKEN = "717635382:AAE9Qy-9Vd0wAsUAVnII9y9CLE-8E-s9EAA"
#webhookURLHeroku = "https://rave-osioluyo.herokuapp.com/717635382:AAE9Qy-9Vd0wAsUAVnII9y9CLE-8E-s9EAA"
#webhookURL = "https://bad72e47.ngrok.io"
#generateBot._generateBot(TOKEN)

#commandManager.runLsCommand("config", writeFile="tt")


#projectManager.createInitProject(createBasicModules=True)

#generateBot._generateBot(TOKEN)

#if(len(sys.argv) < 2):
#    print("--help for more information")


consoleAPI.initProgram(sys.argv)

#print(utils.file_Or_Directory_Exists("bot/", "bot.py"))












